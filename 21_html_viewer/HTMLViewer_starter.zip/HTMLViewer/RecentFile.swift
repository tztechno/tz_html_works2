import Foundation

// A previously-opened file or folder, remembered as a security-scoped
// bookmark so it can be reopened without asking the system file picker again.
struct RecentFile: Identifiable, Codable {
    let id: UUID
    let name: String
    let bookmarkData: Data

    init(name: String, bookmarkData: Data) {
        self.id = UUID()
        self.name = name
        self.bookmarkData = bookmarkData
    }
}

enum RecentFileStore {
    private static let key = "recentHTMLFiles"
    private static let maxItems = 10

    static func load() -> [RecentFile] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let items = try? JSONDecoder().decode([RecentFile].self, from: data) else {
            return []
        }
        return items
    }

    static func save(_ items: [RecentFile]) {
        let trimmed = Array(items.prefix(maxItems))
        guard let data = try? JSONEncoder().encode(trimmed) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}
