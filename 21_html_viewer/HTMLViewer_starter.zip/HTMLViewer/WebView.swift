import SwiftUI
import WebKit

// Thin SwiftUI wrapper around WKWebView.
//
// The important trick, and the whole reason this app exists: WKWebView's
// loadFileURL(_:allowingReadAccessTo:) can load a local file:// HTML file
// with full JavaScript/canvas support, something Safari itself refuses to
// do for files sitting outside its own sandbox. `readAccessURL` should be
// the enclosing folder (not just the HTML file) so relative <script src>,
// <link href>, and image paths inside that folder resolve correctly.
struct WebView: UIViewRepresentable {
    let fileURL: URL
    let readAccessURL: URL

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        // Most HTML5 games/pages assume they can play audio/video without
        // a user tap on the media element itself.
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        // Guard against SwiftUI calling updateUIView repeatedly (e.g. on
        // rotation) and reloading the page from scratch each time.
        guard context.coordinator.loadedURL != fileURL else { return }
        context.coordinator.loadedURL = fileURL
        webView.loadFileURL(fileURL, allowingReadAccessTo: readAccessURL)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    final class Coordinator {
        var loadedURL: URL?
    }
}
