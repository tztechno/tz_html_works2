import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var showingFolderPicker = false
    @State private var showingFilePicker = false

    @State private var currentAccessURL: URL?   // the URL we called startAccessingSecurityScopedResource() on
    @State private var currentIndexURL: URL?    // the actual .html file being shown
    @State private var currentTitle: String = ""

    @State private var recentFiles: [RecentFile] = RecentFileStore.load()

    @State private var showingError = false
    @State private var errorMessage = ""

    var body: some View {
        NavigationStack {
            Group {
                if let indexURL = currentIndexURL, let accessURL = currentAccessURL {
                    WebView(fileURL: indexURL, readAccessURL: accessURL)
                        .ignoresSafeArea(edges: .bottom)
                } else {
                    startScreen
                }
            }
            .navigationTitle(currentIndexURL == nil ? "HTML Viewer" : currentTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if currentIndexURL != nil {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("閉じる") { closeCurrent() }
                    }
                }
            }
        }
        .fileImporter(isPresented: $showingFolderPicker, allowedContentTypes: [.folder]) { result in
            switch result {
            case .success(let url): open(url)
            case .failure(let error): presentError(error.localizedDescription)
            }
        }
        .fileImporter(isPresented: $showingFilePicker, allowedContentTypes: [.html]) { result in
            switch result {
            case .success(let url): open(url)
            case .failure(let error): presentError(error.localizedDescription)
            }
        }
        // Lets "index.html" (or a folder) shared from the Files app via
        // "Open in HTML Viewer" launch straight into this app. Requires the
        // CFBundleDocumentTypes entry described in the README.
        .onOpenURL { url in
            open(url)
        }
        .alert("開けませんでした", isPresented: $showingError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage)
        }
    }

    // MARK: - Start screen

    private var startScreen: some View {
        VStack(spacing: 20) {
            Spacer(minLength: 12)

            Image(systemName: "doc.richtext")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)

            Text("ローカルの index.html を選んで表示します")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)

            VStack(spacing: 12) {
                Button {
                    showingFolderPicker = true
                } label: {
                    Label("フォルダを開く（推奨）", systemImage: "folder")
                        .frame(maxWidth: 300)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    showingFilePicker = true
                } label: {
                    Label("HTMLファイル単体を開く", systemImage: "doc")
                        .frame(maxWidth: 300)
                }
                .buttonStyle(.bordered)

                Text("複数ファイル(css/js/画像)で構成されたページやゲームは、解凍してできたフォルダごと「フォルダを開く」で選んでください。単体のHTMLファイルだけを選ぶと、同じフォルダ内の他のファイルは読み込めません。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }

            if !recentFiles.isEmpty {
                List {
                    Section("最近開いたもの") {
                        ForEach(recentFiles) { item in
                            Button {
                                openRecent(item)
                            } label: {
                                Label(item.name, systemImage: "clock")
                            }
                        }
                        .onDelete { indexSet in
                            recentFiles.remove(atOffsets: indexSet)
                            RecentFileStore.save(recentFiles)
                        }
                    }
                }
                .listStyle(.plain)
            } else {
                Spacer()
            }
        }
        .padding(.top, 24)
    }

    // MARK: - Opening files

    /// Handles a URL coming from either file picker or from the "Open in…" share sheet.
    private func open(_ url: URL) {
        guard url.startAccessingSecurityScopedResource() else {
            presentError("アクセス許可を取得できませんでした")
            return
        }

        let isDirectory = (try? url.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false

        if isDirectory {
            guard let indexURL = findIndexHTML(in: url) else {
                url.stopAccessingSecurityScopedResource()
                presentError("このフォルダの中に index.html が見つかりませんでした")
                return
            }
            currentAccessURL = url
            currentIndexURL = indexURL
            currentTitle = url.lastPathComponent
        } else {
            currentAccessURL = url
            currentIndexURL = url
            currentTitle = url.lastPathComponent
        }

        saveRecent(name: currentTitle, url: url)
    }

    private func openRecent(_ item: RecentFile) {
        var isStale = false
        guard let url = try? URL(
            resolvingBookmarkData: item.bookmarkData,
            options: [],
            relativeTo: nil,
            bookmarkDataIsStale: &isStale
        ) else {
            presentError("このファイルはもう開けません（移動または削除された可能性があります）")
            recentFiles.removeAll { $0.id == item.id }
            RecentFileStore.save(recentFiles)
            return
        }
        open(url)
    }

    private func closeCurrent() {
        currentAccessURL?.stopAccessingSecurityScopedResource()
        currentAccessURL = nil
        currentIndexURL = nil
        currentTitle = ""
    }

    /// Looks for index.html directly inside the folder first (the common
    /// case), then falls back to a recursive search in case the zip
    /// extracted into a nested wrapper folder.
    private func findIndexHTML(in folderURL: URL) -> URL? {
        let fm = FileManager.default

        let topLevel = folderURL.appendingPathComponent("index.html")
        if fm.fileExists(atPath: topLevel.path) {
            return topLevel
        }

        guard let enumerator = fm.enumerator(at: folderURL, includingPropertiesForKeys: nil) else {
            return nil
        }
        for case let fileURL as URL in enumerator where fileURL.lastPathComponent.lowercased() == "index.html" {
            return fileURL
        }
        return nil
    }

    private func saveRecent(name: String, url: URL) {
        guard let bookmark = try? url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) else {
            return
        }
        var items = recentFiles.filter { $0.name != name }
        items.insert(RecentFile(name: name, bookmarkData: bookmark), at: 0)
        recentFiles = items
        RecentFileStore.save(recentFiles)
    }

    private func presentError(_ message: String) {
        errorMessage = message
        showingError = true
    }
}
