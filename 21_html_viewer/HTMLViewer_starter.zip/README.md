# HTML Viewer (自作用スターター)

ローカルのHTMLフォルダ／ファイルを WKWebView で開くだけの、最小構成のiOSアプリです。
BOOTHなどで配布されているHTML型ゲーム(zip)を解凍したフォルダを、Safariでは開けない
`file://` のまま、JavaScript・canvasも含めて表示できます。

## 1. Xcodeで新規プロジェクトを作る

1. Xcode → File → New → Project
2. iOS → **App** を選択
3. Product Name: `HTMLViewer`（任意）、Interface: **SwiftUI**、Language: **Swift**
4. Team は自分の無料Apple IDでOK（後述の制限あり）
5. できたプロジェクトの `ContentView.swift` を、このフォルダの `HTMLViewer/ContentView.swift` の中身で **上書き**
6. このフォルダの `HTMLViewer/WebView.swift` と `HTMLViewer/RecentFile.swift` を、Xcodeのプロジェクトナビゲータにドラッグ＆ドロップして追加（"Copy items if needed" にチェック）
7. `HTMLViewerApp.swift` も同様に中身を上書き（`@main` の構造体名だけ、プロジェクト作成時に決めた名前に合わせてください）

対応iOS: 15以降を推奨（`.alert` の新API、`.fileImporter` を使っています）。
Xcodeのプロジェクト設定 → General → Minimum Deployments で iOS 15 以上に設定してください。

## 2. 「他のAppで開く」対応にする（任意だけどおすすめ）

これを設定すると、Filesアプリで index.html を長押し→共有→「HTML Viewerで開く」が
できるようになります。Xcode の対象(Target) → **Info** タブで以下を追加します。

- **Document Types** セクションに1つ追加
  - Name: `HTML`
  - Types: `public.html`
  - Handler rank: `Alternate`
- カスタムキーを追加
  - `Supports opening documents in place` (`LSSupportsOpeningDocumentsInPlace`) = `YES`

これがなくても、アプリ内の「フォルダを開く」ボタンから毎回選べば動作します。

## 3. 実機にインストールする

1. iPhoneをMacにケーブル接続
2. Xcode上部の実行先をあなたのiPhoneに切り替える
3. ▶︎ (Run) を押す
4. 初回はiPhone側で「設定 → 一般 → VPNとデバイス管理」からデベロッパを信頼する必要があります

**重要な制限**: 有料のApple Developer Program（年間$99）に入っていない無料のApple IDだと、
インストールしたアプリは **7日で使えなくなります**。7日ごとにMacに繋いでXcodeから
再インストール（Runし直す）すれば無料のまま使い続けられます。毎回繋ぐのが面倒なら
有料プログラムへの加入を検討してください。

## 4. 使い方

1. BOOTHでダウンロードしたzipをiPhoneの「ファイル」アプリでタップ → 自動的に同名フォルダに解凍されます
2. このアプリを開き、「フォルダを開く」でその解凍されたフォルダを選ぶ
3. フォルダの中(または1階層下)にある `index.html` を自動的に探して表示します

「HTMLファイル単体を開く」は index.html だけを選ぶボタンですが、その場合は同じ
フォルダ内のCSS/JS/画像などの他のファイルは読み込めません(iOSのセキュリティスコープが
選んだファイル1つに限定されるため)。複数ファイル構成のゲーム・ページは必ず
「フォルダを開く」を使ってください。

## ファイル構成

```
HTMLViewer/
  HTMLViewerApp.swift   … アプリのエントリーポイント
  ContentView.swift     … 画面・ファイル選択・履歴のロジック
  WebView.swift         … WKWebViewをSwiftUIから使うためのラッパー
  RecentFile.swift       … 「最近開いたファイル」の保存
```
