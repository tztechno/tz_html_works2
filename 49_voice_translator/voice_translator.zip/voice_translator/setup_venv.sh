#!/usr/bin/env bash
# Create a virtual environment and install dependencies for voice_translator.py
set -e
cd "$(dirname "$0")"

# Use a Python that ships with tkinter (python.org installer or Homebrew + python-tk)
PY=${PYTHON:-python3}
if ! "$PY" -c "import tkinter" 2>/dev/null; then
  echo "tkinter not found for $PY. Run: brew install python-tk@\$(\"$PY\" -c 'import sys;print(f\"{sys.version_info[0]}.{sys.version_info[1]}\")')"
  exit 1
fi

"$PY" -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo
echo "Done. Run:"
echo "  source .venv/bin/activate"
echo "  python voice_translator.py"
