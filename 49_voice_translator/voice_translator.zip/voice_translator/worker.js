// Cloudflare Worker for Kotoba Booth
// - Serves the static site in ./site (via the ASSETS binding)
// - Proxies model files from Hugging Face at /hf/<repo>/resolve/<rev>/<file>,
//   because huggingface.co does not return CORS headers to *.workers.dev origins.

// Only these model repos may be fetched through the proxy
const ALLOWED_REPOS = ["Kadonox/fugumt-en-ja-onnx", "Kadonox/fugumt-ja-en-onnx"];

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/hf/")) {
      if (request.method !== "GET" && request.method !== "HEAD") {
        return new Response("Method not allowed", { status: 405 });
      }
      const path = url.pathname.slice(4); // "<owner>/<repo>/resolve/<rev>/<file>"
      const repo = path.split("/").slice(0, 2).join("/");
      if (!ALLOWED_REPOS.includes(repo) || !/^[^/]+\/[^/]+\/resolve\/[^/]+\/.+/.test(path) || path.includes("..")) {
        return new Response("Not allowed", { status: 403 });
      }

      // Forward Range so partial downloads work; follow HF's redirect to its CDN
      const headers = new Headers();
      const range = request.headers.get("Range");
      if (range) headers.set("Range", range);

      const upstream = await fetch("https://huggingface.co/" + path, {
        method: request.method,
        headers,
        redirect: "follow",
        cf: { cacheEverything: true, cacheTtl: 60 * 60 * 24 * 30 }, // cache at the edge for 30 days
      });

      const out = new Headers(upstream.headers);
      out.set("Access-Control-Allow-Origin", "*");
      out.set("Cache-Control", "public, max-age=2592000, immutable");
      out.delete("Set-Cookie");
      return new Response(upstream.body, { status: upstream.status, headers: out });
    }

    // Everything else: static files from ./site
    return env.ASSETS.fetch(request);
  },
};
